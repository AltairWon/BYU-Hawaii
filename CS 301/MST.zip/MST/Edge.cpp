#include "Edge.h"

//set the node a and node b and weight w
Edge::Edge(Node* a, Node* b, int w) {

	n1 = a;
	n2 = b;
	weight = w;
}
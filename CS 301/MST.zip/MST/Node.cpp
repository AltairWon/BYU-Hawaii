#include "Node.h"

//set the name for n and bool for visited as false
Node::Node(string n) {
	name = n;
	visited = false;
}

//set the add neighbor for the edge
void Node::addNeighbor(Edge* e) {
	neighbors.push_back(e);
}
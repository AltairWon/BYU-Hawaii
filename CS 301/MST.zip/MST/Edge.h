#pragma once
#include "Node.h"

class Node;
class Edge {
public:
	Edge(Node*, Node*, int);

	Node* n1;
	Node* n2;
	int weight;
};
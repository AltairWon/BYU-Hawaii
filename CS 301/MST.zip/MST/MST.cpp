#include <iostream>
#include <fstream>
#include <string>
#include "Node.h"
#include "Edge.h"
#include <vector>
#include <map>
#include <sstream>

using namespace std;
vector<Edge*> bucket;

//start with the best edge
Edge* getBestEdge() {
	//TODO
	Edge* best = NULL;
	while (best == NULL && bucket.size() != 0) {
		best = bucket[0];
		int bestIndex = 0;
		for (int i = 1; i < bucket.size(); i++) {
			Edge* e = bucket[i];
			if (e->weight < best->weight) {
				best = e;
				bestIndex = i;
			}
		}
		if (best->n1->visited && best->n2->visited) {
			bucket.erase(bucket.begin() + bestIndex);
			best = NULL;
		}
	}
	return best;
}

//set the prime for the minimal spanning tree
void mstPrim(Node* start) {
	vector<Edge*> MST_EDGES;
	int total_weight = 0;
	//add all of start's adjacent edges to bucket
	for (Edge* e : start->neighbors) {
		bucket.push_back(e);
	}
	Edge* E = getBestEdge();
	while (E != NULL) {
		Node* e1 = E->n1;
		Node* e2 = E->n2;
		E->n1->visited = true;
		E->n2->visited = true;
		total_weight += E->weight;
		MST_EDGES.push_back(E);
		for (Edge* e : e1->neighbors) {
			bucket.push_back(e);
		}
		for (Edge* e : e2->neighbors) {
			bucket.push_back(e);
		}
		E = getBestEdge();
	}
	//print the results of the words
	cout << "MST has a weight of " << total_weight << " and consists of these edges :" << endl;
	for (Edge* p : MST_EDGES) {
		cout << p->n1->name << " - " << p->n2->name << endl;
	}

}

map<string, Node*> nodes;

int main(int argc, char** argv) {

	//file does not exits 
	if (argc != 2) {
		cout << "Are you forgetting the command-line parameter?" << endl;
		return 0;
	}
	ifstream ifs;
	ifs.open(argv[1], ios::in);

	//file name is error
	if (!ifs) {
		cout << "Error! Please check filename." << endl;
	}
	else {
		string tmp;
		getline(ifs, tmp);
		for (int i = 0; i < tmp.size(); i++) {
			char label = tmp[i];
			Node* node = new Node(string(1, label));
			nodes[node->name] = node;
			//cout<<node->name<<endl;
		}
		getline(ifs, tmp);
		int n = stoi(tmp);
		for (int i = 0; i < n; i++) {
			getline(ifs, tmp);
			string labelA, labelB;
			int w;
			stringstream ss(tmp);
			ss >> labelA >> labelB >> w;
			Node* nodeA = nodes[labelA];
			Node* nodeB = nodes[labelB];
			Edge* ed = new Edge(nodeA, nodeB, w);
			nodeA->addNeighbor(ed);
			nodeB->addNeighbor(ed);
		}
		//set the result
		mstPrim(nodes["A"]);
	}
	//TODO
}



// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started:
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file


#pragma once
#include "Edge.h"
#include <string>
#include <vector>

using namespace std;
class Edge;
class Node {
public:
	Node(string);
	void addNeighbor(Edge*);
	string name;
	bool visited;
	vector<Edge*> neighbors;
};
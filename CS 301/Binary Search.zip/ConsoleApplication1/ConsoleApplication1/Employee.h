#pragma once

#include <string>
using namespace std;

class Employee
{
public:
	Employee(string, int, int, string, int);
	Employee(int);
	~Employee();
	void printStatus();

public:
	int age;
	string name;
	string job;
	int id;
	int year;
	int number;
};


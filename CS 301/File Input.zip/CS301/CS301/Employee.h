#pragma once

#include <string>
using namespace std;

class Employee
{
public:
	Employee(string, int, int, string, int);
	~Employee();
	void printStatus();

private:
	int age;
	string name;
	string job;
	int id;
	int year;
};


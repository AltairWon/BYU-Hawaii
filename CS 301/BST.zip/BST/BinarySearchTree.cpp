// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

Node* root;


int main(int argc, char** argv)
{
	if (argc != 2) {
		cout << "Are you forgetting the command-line parameter?" << endl;
		return 0;
	}
	ifstream ifs;
	//ios::in = �б⸸ ������ ���·� ������ �����Ѵ�.
	ifs.open(argv[1], ios::in);
	if (!ifs) {
		cout << "Error! Please check filename." << endl;
	}
	else {
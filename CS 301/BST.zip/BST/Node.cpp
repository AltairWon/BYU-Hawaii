#include "Node.h"

Node::Node(int k) {
	key = k;
}
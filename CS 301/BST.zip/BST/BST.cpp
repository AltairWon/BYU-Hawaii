#include "Node.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;
Node* root;

//inseart the tree
void insert(Node* z) {
	Node* y = NULL;
	Node* x = root;
	while (x != NULL) {
		y = x;
		if (z->key < x->key) {
			x = x->left;
		}
		else {
			x = x->right;
		}
	}
	if (y == NULL) {
		//tree T was empty
		root = z;
	}
	else if (z->key < y->key) {
		y->left = z;
	}
	else {
		y->right = z;
	}
}

//search the node for BST
Node* search(Node* x, int k) {
	if (x == NULL) {
		return x;
	}
	else if (k == x->key) {
		cout << x->key << " ";
		return x;
	}
	cout << x->key << " ";
	if (k < x->key) {
		return search(x->left, k);
	}
	else {
		return search(x->right, k);
	}
}

//preorder for the node of BST
void preorder(Node* n) {
	if (n != NULL) {
		cout << n->key << " ";
		preorder(n->left);
		preorder(n->right);
	}
}

//inorder for the node of BST
void inorder(Node* n) {
	if (n != NULL) {
		inorder(n->left);
		cout << n->key << " ";
		inorder(n->right);
	}
}

//inorder for the node of BST
void postorder(Node* n) {
	if (n != NULL) {
		postorder(n->left);
		postorder(n->right);
		cout << n->key << " ";
	}
}




int main(int argc, char** argv)
{
	if (argc != 2) {
		cout << "Are you forgetting the command-line parameter?" << endl;
		return 0;
	}
	ifstream ifs;
	//ios::in = �б⸸ ������ ���·� ������ �����Ѵ�.
	ifs.open(argv[1], ios::in);
	if (!ifs) {
		cout << "Error! Please check filename." << endl;
		return 0;
	}
	else {
		//make the new Employee integer number
		string tmp;
		getline(ifs, tmp);
		int m = stoi(tmp);
		for (int i = 0; i < m; i++) {
			getline(ifs, tmp);
			string cmd;
			int k;
			stringstream ss(tmp);
			ss >> cmd;
			if (cmd == "CLEAR") {
				//TODO
				root = NULL;
				cout << "(tree deleted!)" << endl;

			}
			if (cmd == "PREORDER") {
				cout << "PREORDER: ";
				preorder(root);
				cout << endl;
			}
			if (cmd == "INORDER") {
				cout << "INORDER: ";
				inorder(root);
				cout << endl;
				

			}
			if (cmd == "POSTORDER") {
				cout << "POSTORDER: ";
				postorder(root);
				cout << endl;
			}
			if (cmd == "ADD") {
				ss >> k;
				Node* foo = new Node(k);
				insert(foo);
				cout << "Adding " << k << endl;
			}
			if (cmd == "FIND") {
				ss >> k;
				//Node* foo = search(root, k);
				//print out results;
				cout << "Looking for " << k << "...";
				if (search(root, k) != NULL) {
					cout << " :found" << endl;
				}
				else {
					cout << " : Not found" << endl;
				}

			}

		}
	}
}
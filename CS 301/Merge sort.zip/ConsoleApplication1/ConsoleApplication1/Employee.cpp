#include "stdafx.h"
#include "Employee.h"
#include <iostream>

using namespace std;

Employee::Employee(string n, int i, int a, string j, int y)
{
	name = n;
	id = i;
	age = a;
	job = j;
	year = y;
}

Employee::Employee(int n) 
{
	number = n;
}

void Employee::printStatus() {
	cout << "Name:			" << name << endl;
	cout << "ID:			" << id << endl;
	cout << "Age:			" << age << endl;
	cout << "job:			" << job << endl;
	cout << "Year of Hired:	" << year << endl;
	cout << "***************" << endl;
}


void Employee::output(ofstream& ofs) {
	cout << "Name:			" << name << endl;
	cout << "ID:			" << id << endl;
	cout << "Age:			" << age << endl;
	cout << "job:			" << job << endl;
	cout << "Year of Hired:	" << year << endl;
	cout << "***************" << endl;
}
Employee::~Employee()
{
	//nothing in there
}


package com.example.battleship.Sprite;

import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

import com.example.battleship.R;

public class Battleship extends Sprite {

    public Battleship(Resources res) {
        super();
        /**
         * set the bounds and image for battleship
         */
        bounds = new RectF();
        image = BitmapFactory.decodeResource(res, R.drawable.battleship);

    }


    @Override
    protected float relativewidth() {
        return 0.25f;
    }

}

package com.example.battleship.Sprite;

public abstract class Enemy extends Sprite {
}



package com.example.battleship.Sprite;

import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

import com.example.battleship.R;

import java.util.Random;

import static com.example.battleship.Sprite.Size.*;

public class Submarine extends Enemy {
    /**set random numbers for random picked submarines
     *
     */
    Random random = new Random();
        int n;
        private Size size;

    public Submarine(Resources res) {
            bounds = new RectF();
        /**set n as random between 1-3
         * 
         */
        n = random.nextInt(3);
            if (n == 1) {
                image = BitmapFactory.decodeResource(res, R.drawable.big_submarine);
                size = LARGE;
            } else if (n == 2){
                image = BitmapFactory.decodeResource(res, R.drawable.medium_submarine);
                size = MEDIUM;
            } else {
                image = BitmapFactory.decodeResource(res, R.drawable.little_submarine);
                size = SMALL;
            }
        }

        @Override
        protected float relativewidth() {
            if (size == LARGE) {
                return 0.1f;
            } else if (size == MEDIUM) {
                return 0.08f;
            } else {
                return 0.04f;
            }
        }
}

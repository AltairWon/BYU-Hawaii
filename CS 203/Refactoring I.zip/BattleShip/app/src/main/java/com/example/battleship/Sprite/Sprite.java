package com.example.battleship.Sprite;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.RectF;

public abstract class Sprite {
    /**set bitmap and rectf
     *
     */
    public Bitmap image;
    public RectF bounds;

    public Sprite() { }

    /**set relative width
     *
     * @return
     */
    protected abstract float relativewidth();

    /**
     * make the scale structure for screen width
     * @param screenWidth
     */
    public void scale(float screenWidth) {
        float scaleWidth = screenWidth * relativewidth();
        float scaleHeight = scaleWidth * ((float)image.getHeight()/(float)image.getWidth());
        image = Bitmap.createScaledBitmap(image, (int)scaleWidth, (int)scaleHeight,true);
        bounds.set(0,0, scaleWidth, scaleWidth);
    }

    /**
     * make the set position for the x and y for subclasses
     * @param x
     * @param y
     */
    public void setPosition(float x, float y) {
        bounds.offsetTo(x-image.getWidth()/2,y-image.getHeight()/2);

    }

    /**
     * make draw structure for drawing the subclasses
     * @param c
     */
    public void draw(Canvas c) {
        c.drawBitmap(image, bounds.left, bounds.top, null);
    }

}
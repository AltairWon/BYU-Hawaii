package com.example.battleship.Subclass;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.View;

import com.example.battleship.R;
import com.example.battleship.Sprite.Airplane;
import com.example.battleship.Sprite.Battleship;
import com.example.battleship.Sprite.Submarine;

public class Mockup extends View {

    private Battleship battleship;
    private Airplane plane1, plane2, plane3;
    private Submarine sub1, sub2, sub3;
    private Bitmap water;


    private boolean init;


    public Mockup(Context c) {
        super(c);
        init = false;
        /**instantiate all classes
         *
         */
        battleship = new Battleship(getResources());
        plane1 = new Airplane(getResources());
        plane2 = new Airplane(getResources());
        plane3 = new Airplane(getResources());
        sub1 = new Submarine(getResources());
        sub2 = new Submarine(getResources());
        sub3 = new Submarine(getResources());
        /**make water constructor
         *
         */
        water = BitmapFactory.decodeResource(getResources(), R.drawable.water);

    }

    @Override
    public void onDraw(Canvas c) {
        float w = c.getWidth();
        float h = c.getHeight();
        if (init == false) {


            /**set battleship's scale size and position
             *
             */
            battleship.scale(w);
            battleship.setPosition(w/2, h/2.38f);
            /**set airplanes' scales and positions
             *
             */
            plane1.scale(w);
            plane1.setPosition(w/5, h/3.5f);
            plane2.scale(w);
            plane2.setPosition(w/1.8f, h/8.9f);
            plane3.scale(w);
            plane3.setPosition(w/1.2f, h/5.4f);
            /**set submarines' scales and positions
             *
             */
            sub1.scale(w);
            sub1.setPosition(w/5, h/1.1f);
            sub2.scale(w);
            sub2.setPosition(w/2, h/1.7f);
            sub3.scale(w);
            sub3.setPosition(w/1.1f, h/1.4f);
            /**set water scale size
             *
             */
            float waterSize1 = w *0.17f;
            float waterSize2 = h *0.03f;
            water = Bitmap.createScaledBitmap(water,
                    (int)waterSize1, (int)waterSize2, true);


            init = true;
        }
        /**make background for white color
         *
         */
        c.drawColor(Color.WHITE);
        /**set water
         *
         */
        float waterPosX = w/6;
        float waterPosY = h/2 - water.getHeight();
        c.drawBitmap(water, 0, waterPosY, null);
        c.drawBitmap(water, waterPosX, waterPosY, null);
        c.drawBitmap(water, waterPosX * 2, waterPosY,null);
        c.drawBitmap(water, waterPosX * 3, waterPosY, null);
        c.drawBitmap(water, waterPosX * 4, waterPosY, null);
        c.drawBitmap(water, waterPosX * 5, waterPosY, null);
        c.drawBitmap(water, waterPosX * 6, waterPosY, null);
        /**draw battleship, airplanes, and submarines
         *
         */
        battleship.draw(c);
        plane1.draw(c);
        plane2.draw(c);
        plane3.draw(c);
        sub1.draw(c);
        sub2.draw(c);
        sub3.draw(c);

    }
}
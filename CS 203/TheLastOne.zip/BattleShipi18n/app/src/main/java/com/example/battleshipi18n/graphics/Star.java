package com.example.battleshipi18n.graphics;


import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.RectF;

import com.example.battleshipi18n.misc.Direction;

public class Star extends Sprite {

    private Direction direction;
    private boolean disappear;

    /**
     * make image
     * @param res
     * @param dir
     */
    public Star(Resources res, Direction dir) {
        super();
        bounds = new RectF();
        this.direction = dir;
        //image = BitmapFactory.decodeResource(res, R.drawable.star);
        image = ImageCache.getCannonFire();
    }

    /**
     * relative width
     * @return
     */
    /*@Override
    protected float relativewidth() {
        return 0.1f;
    }

     */


    /**
     * setting the position of the image
     * @param x
     * @param y
     */
    @Override
    public void setPosition(float x,float y) {
        if (direction == Direction.LEFT_TO_RIGHT) {
            bounds.offsetTo(x,y);
        }
        if (direction == Direction.RIGHT_TO_LEFT) {
            bounds.offsetTo(x, y);

        }
    }

    /**
     * making the draw and setting the disappear is true
     * @param c
     */
    @Override
    public void draw(Canvas c) {
        super.draw(c);
        disappear = true;
    }

    /**
     * make getDisappear for returning disappear
     * @return
     */
    public boolean getDisappear() {
        return disappear;
    }


    @Override
    public void tick() {
        move();
    }
}

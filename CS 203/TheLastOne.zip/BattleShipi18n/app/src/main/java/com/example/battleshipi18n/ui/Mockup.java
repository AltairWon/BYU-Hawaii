package com.example.battleshipi18n.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.MediaPlayer;
import android.view.MotionEvent;
import android.view.View;

import com.example.battleshipi18n.R;
import com.example.battleshipi18n.graphics.Airplane;
import com.example.battleshipi18n.graphics.Battleship;
import com.example.battleshipi18n.graphics.DepthCharge;
import com.example.battleshipi18n.graphics.Enemy;
import com.example.battleshipi18n.graphics.ImageCache;
import com.example.battleshipi18n.graphics.Missile;
import com.example.battleshipi18n.graphics.Sprite;
import com.example.battleshipi18n.graphics.Star;
import com.example.battleshipi18n.graphics.Submarine;
import com.example.battleshipi18n.misc.Direction;
import com.example.battleshipi18n.misc.Size;
import com.example.battleshipi18n.misc.TickListener;
import com.example.battleshipi18n.misc.Timer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;


/**
 * put the view class with implements TickListener
 */
public class Mockup extends View implements TickListener {

    private Battleship battleship;
    private List<Airplane> planes;
    private List<Submarine> submarines;
    private List<DepthCharge> charges;
    private List<Missile> missiles;
    private List<Star> star;
    private Bitmap water;
    private boolean init;
    private Timer timer;
    private int score;
    private int timeLeft;
    private long timeBefore, timeNew;
    private MediaPlayer depth_charge;
    private MediaPlayer left_gun;
    private MediaPlayer plane_explode;
    private MediaPlayer right_gun;
    private MediaPlayer sub_explode;
    private MediaPlayer song;

    /**instantiate all classes
     *
     */
    public Mockup(Context c) {
        super(c);
        init = false;
        planes = new ArrayList<>();
        submarines = new ArrayList<>();
        charges = new ArrayList<>();
        missiles = new ArrayList<>();
        star = new ArrayList<>();
        timer = new Timer();
        depth_charge = MediaPlayer.create(getContext(), R.raw.depth_charge);
        left_gun = MediaPlayer.create(getContext(), R.raw.left_gun);
        right_gun = MediaPlayer.create(getContext(), R.raw.right_gun);
        plane_explode = MediaPlayer.create(getContext(), R.raw.plane_explode);
        sub_explode = MediaPlayer.create(getContext(), R.raw.sub_explode);
        song = MediaPlayer.create(getContext(), R.raw.avengers_theme);
        song.setLooping(true);



        //water = BitmapFactory.decodeResource(getResources(), R.drawable.water);
    }



    /**
     * make the scale and position of all objects on onDraw method
     * @param c
     */
    @Override
    public void onDraw(Canvas c) {
        c.drawColor(Color.WHITE);
        int w = getWidth();
        int h = getHeight();
        if (init == false) {
            init = true;
            //todo because I reset the all app, I do not have to put every drawing methods
            Enemy.setPreference(Preference.getSpeedPref(getContext()), Preference.getDirectionPref(getContext()));
            resetGame();
        }


        //todo draw everything
        for (Airplane a : planes) {
            a.draw(c);
        }
        for (Submarine s : submarines) {
            s.draw(c);
        }

        float waterPosX = w/6;
        float waterPosY = h/2 - water.getHeight();
        c.drawBitmap(water, 0, waterPosY, null);
        c.drawBitmap(water, waterPosX * 0.5f, waterPosY,null);
        c.drawBitmap(water, waterPosX, waterPosY, null);
        c.drawBitmap(water, waterPosX * 1.5f, waterPosY,null);
        c.drawBitmap(water, waterPosX * 2, waterPosY,null);
        c.drawBitmap(water, waterPosX * 2.5f, waterPosY,null);
        c.drawBitmap(water, waterPosX * 3, waterPosY, null);
        c.drawBitmap(water, waterPosX * 3.5f, waterPosY,null);
        c.drawBitmap(water, waterPosX * 4, waterPosY, null);
        c.drawBitmap(water, waterPosX * 4.5f, waterPosY,null);
        c.drawBitmap(water, waterPosX * 5, waterPosY, null);
        c.drawBitmap(water, waterPosX * 5.5f, waterPosY,null);

        battleship.draw(c);

        //paint the score on the screen
        Paint p = new Paint();
        //set the color as black
        p.setColor(Color.BLACK);
        //set the text size
        p.setTextSize(80);
        //use canvas for drawing text with using text and new paint p
        c.drawText("SCORE: " + score, 10, h/1.8f, p);

        //set the timer
        //make the string the timer inter to string to show the text
        String timesleft = Integer.toString(timeLeft/60)+':';
        //if timeleft is more than 10, show time
        if (timeLeft%60>=10){
            timesleft = timesleft+Integer.toString(timeLeft%60);
        //if not, show 0 to put extra 0
        }else {
            timesleft = timesleft+'0'+Integer.toString(timeLeft%60);
        }
        c.drawText("TIME: " + timesleft, w/1.2f,h/1.8f,p);


        //if the time is going to zero, put the box!
        if (timeLeft == 0){
            //endgame
            //set the current score as score
            int currentscore = score;
            String altiar = getResources().getString(R.string.altair_game_over);
            //load the score on the save file
            loadScore();

            //if the currentscore is higher than the score that loaded, say new high score and play agian?
            if (currentscore > score) {
                altiar += getResources().getString(R.string.altair_question);
                AlertDialog.Builder ab = new AlertDialog.Builder(getContext());
                ab.setTitle(R.string.app_name)
                        .setMessage(altiar)
                        .setCancelable(false)
                        //Lambda syntax
                        .setPositiveButton(R.string.altair_yes, (d,i) -> {
                            score = currentscore;
                            saveScore();
                            planes.clear();
                            submarines.clear();
                            charges.clear();
                            missiles.clear();
                            star.clear();
                            timer.setPaused(true);
                            resetGame();
                        })
                        //anonymous class syntax
                        .setNegativeButton(R.string.altair_no, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int i) {
                                Activity parent = (Activity)getContext();
                                parent.finish();
                            }
                        });
                AlertDialog box = ab.create();
                box.show();

                //if the score is not the high score, show box and say play again
            }else {
                altiar += getResources().getString(R.string.altair_question);
                AlertDialog.Builder ab = new AlertDialog.Builder(getContext());
                ab.setTitle(R.string.app_name)
                        .setMessage(altiar)
                        .setCancelable(false)
                        .setPositiveButton(R.string.altair_yes, (d,i) -> {
                            planes.clear();
                            submarines.clear();
                            charges.clear();
                            missiles.clear();
                            star.clear();
                            timer.setPaused(true);
                            resetGame();
                        })
                        .setNegativeButton(R.string.altair_no, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int i) {
                                Activity parent = (Activity)getContext();
                                parent.finish();
                            }
                        });
                AlertDialog box = ab.create();
                box.show();
            }
        }




        for (DepthCharge d : charges) {
            d.draw(c);
        }

        for (Missile m : missiles) {
            m.draw(c);
        }

        ArrayList<Star> tresh = new ArrayList<>();
        for (Star s : star) {
            if (s.getDisappear() == false){
                s.draw(c);
            } else  {
                tresh.add(s);
            }
        }

        for (Star st : tresh) {
            star.remove(st);

        } tresh.clear();
    }

    /**
     *  make the onTouch Event
     * @param m
     * @return
     */
    @Override
    public boolean onTouchEvent(MotionEvent m) {
        float x = m.getX();
        float y = m.getY();
        //List<Missile> mis;
        //mis = new ArrayList<Missile>();
        //List<DepthCharge> doomed = new ArrayList<>();
        if (m.getAction() == MotionEvent.ACTION_DOWN) {
            if (y > getHeight() / 2) {
                if(!Preference.getFireDepthPref(getContext())) {
                    if(charges.size() < 1) {
                        DepthCharge ch = new DepthCharge();
                        timer.subscribe(ch);
                        ch.setPosition(getWidth() / 2, getHeight() / 2);
                        charges.add(ch);
                    }
                } else  {
                    DepthCharge ch = new DepthCharge();
                    timer.subscribe(ch);
                    ch.setPosition(getWidth() / 2, getHeight() / 2);
                    charges.add(ch);
                }
                if(Preference.getMusicPref(getContext())) {
                    depth_charge.start();
                }
            } else {
                Missile mi;
                Star st;
                if (x < getWidth() / 2) {
                    if(!Preference.getFireMissilePref(getContext())) {
                        if(missiles.size() < 1) {
                            mi = new Missile(Direction.RIGHT_TO_LEFT);
                            mi.setPosition(getWidth() * 0.37f, getHeight() * 0.315f);
                            st = new Star(getResources(), Direction.RIGHT_TO_LEFT);
                            st.setPosition(getWidth() * 0.41f, getHeight() * 0.38f);
                            missiles.add(mi);
                            timer.subscribe(mi);
                            star.add(st);
                        }
                    } else {
                            mi = new Missile(Direction.RIGHT_TO_LEFT);
                            mi.setPosition(getWidth() * 0.37f, getHeight() * 0.315f);
                            st = new Star(getResources(), Direction.RIGHT_TO_LEFT);
                            st.setPosition(getWidth()*0.41f, getHeight()*0.38f);
                            missiles.add(mi);
                            timer.subscribe(mi);
                            star.add(st);
                    }
                    if(Preference.getMusicPref(getContext())) {
                        right_gun.start();
                    }

                } else {
                    if(!Preference.getFireMissilePref(getContext())) {
                        if(missiles.size() <1 ) {
                            mi = new Missile(Direction.LEFT_TO_RIGHT);
                            mi.setPosition(getWidth() * 0.58f, getHeight() * 0.315f);
                            st = new Star(getResources(), Direction.LEFT_TO_RIGHT);
                            st.setPosition(getWidth() * 0.58f, getHeight() * 0.37f);
                            missiles.add(mi);
                            timer.subscribe(mi);
                            star.add(st);
                        }
                    } else {
                        mi = new Missile(Direction.LEFT_TO_RIGHT);
                        mi.setPosition(getWidth() * 0.58f, getHeight() * 0.315f);
                        st = new Star(getResources(), Direction.LEFT_TO_RIGHT);
                        st.setPosition(getWidth() * 0.58f, getHeight() * 0.37f);
                        missiles.add(mi);
                        timer.subscribe(mi);
                        star.add(st);
                    }
                    if(Preference.getMusicPref(getContext())) {
                        left_gun.start();
                    }
                }

            }
            cleanupOffscreenObjects();
        }
        /*for (DepthCharge d : charges) {
            if (d.getTop() > getHeight()) {
                doomed.add(d);
                timer.unsubscribe(d);

            }
        }

        for (DepthCharge d : doomed) {
            charges.remove(d);
        }
        doomed.clear();


        for (Missile mi : missiles) {
            if (mi.getBottom() < 0) {
                mis.add(mi);
                timer.unsubscribe(mi);
            }
        }

        for (Missile ms : mis) {
            missiles.remove(ms);
        }
        mis.clear();*/

        return true;
    }
    /**
     * Override the tick on TickListener
     */
    @Override
    public void tick() {
        invalidate();
        detectCollisions();
        timeNew = System.currentTimeMillis();
        if (timeNew - timeBefore>1000) {
            timeLeft --;
            timeBefore = System.currentTimeMillis();
        }
        if(timeLeft ==0){
            timer.setPaused(true);
        }
    }

    /**
     * make the clean off the screen objects of each depth charge and missiles
     */
    private void cleanupOffscreenObjects() {
        //clean up depth charges that go off-screen
        /*List<Sprite> doomed = new ArrayList<>();
        for (DepthCharge dc : charges) {
            if (dc.getTop() > getHeight()) {
                doomed.add(dc);
            }
        }
        for (Sprite d : doomed) {
            charges.remove(d);
            timer.unsubscribe(d);
        }
        doomed.clear();

        //clean up missiles that go off-screen
        for (Missile dc : missiles) {
            if (dc.getBottom() < 0) {
                doomed.add(dc);
            }
        }
        for (Sprite d : doomed) {
            missiles.remove(d);
            timer.unsubscribe(d);
        }*/
        List<Missile> doomed = missiles.stream().filter(a -> a.getBottom()<0).collect(Collectors.toList());
        doomed.forEach(missile -> timer.unsubscribe(missile));
        missiles.removeIf(missile -> missile.getBottom()<0);

        List<DepthCharge> trash = charges.stream().filter(b -> b.getTop()>getHeight()).collect(Collectors.toList());
        trash.forEach(depthCharge -> timer.unsubscribe(depthCharge));
        charges.removeIf(depthCharge -> depthCharge.getTop()>getHeight());

    }

    /**
     * make the detectCollisions for detecting the missiles, airplane, and depthcharge, submarine
     */
    public void detectCollisions() {
        //set the new arraylist for Sprite because they need to start and delete the enemies objects
        //ArrayList<Sprite> trash = new ArrayList<>();
        for (Airplane p : planes) {
            for (Missile m : missiles) {
                if (p.overlaps(m)) {
                    p.explode();
                    if(Preference.getMusicPref(getContext())) {
                        plane_explode.start();
                    }
                    score += p.getPointValue();
                    //hide the missile charge off-screen; it will get cleaned
                    //up at the next touch event.
                    m.setPosition(0,-ImageCache.screenHeight());
                }
            }
        }
        //delete the sprite arraylist because it shows out of window.
        /*for(Sprite s1 : trash) {
            missiles.remove(s1);
        }
        trash.clear();*/

        for (Submarine s : submarines) {
            for (DepthCharge d : charges) {
                if (d.overlaps(s)) {
                    s.explode();
                    if(Preference.getMusicPref(getContext())) {
                        sub_explode.start();
                    }
                    score += s.getPointValue();
                    //hide the depth charge off-screen; it will get cleaned
                    //up at the next touch event.
                    d.setPosition(0,ImageCache.screenHeight());
                }
            }
        }

        // delete the sprite arraylist because it shows out of window
        /*for (Sprite s2 : trash) {
            charges.remove(s2);
        }
        trash.clear();*/

    }

    /**
     * reset the game
     * sine the game needs to reset everything, I need to put everything inside of one method for imagecache
     */
    public void resetGame(){
        int w = getWidth();
        int h = getHeight();
        ImageCache.init(getResources(), w, h);

        water = ImageCache.getWaterImage();
        //TODO instance the battleship singleton pattern
        battleship = Battleship.getInstance();
        float battleshipX = w/2-battleship.getWidth()/2; //center the ship
        float battleshipY = h/2-battleship.getHeight()+water.getHeight(); //put the ship above the water line
        battleship.setPosition(battleshipX, battleshipY);

        //inform Airplane class of acceptable upper/lower limits of flight
        Airplane.setSkyLimits(0, battleship.getTop()-ImageCache.getAirplaneImage(Size.LARGE, Direction.RIGHT_TO_LEFT).getHeight()*2);

        //inform Submarine class of acceptable upper/lower limits of depth
        Submarine.setWaterDepth(h/2 + water.getHeight()*2, h-water.getHeight()*2);

        //instantiate enemy vessels, currently hardcoded to just 3 each
        for (int i=0; i<Preference.getNumberPref(getContext()); i++) {
            planes.add(new Airplane());
            submarines.add(new Submarine());
        }

        //Once everything is in place, start the animation loop!
        timer = new Timer();
        for (Airplane p : planes) {
            timer.subscribe(p);
        }
        for (Submarine s : submarines) {
            timer.subscribe(s);
        }
        timer.subscribe(this);
        score = 0;
        timeBefore = System.currentTimeMillis();
        timeLeft =180;


    }

    /**
     * save the score files
     * save the file as score.txt and put the score ""
     */
    public void saveScore() {
        //Todo part 3 Modify it to use "try with resources" syntax.
        try (final FileReader reader= new FileReader("score.txt")){
            FileOutputStream fos = getContext().openFileOutput("score.txt", Context.MODE_PRIVATE);
            String ivan = ""+score;
            fos.write(ivan.getBytes());
            //fos.close();
        } catch (IOException e) {
        }
    }

    /**
     * save the load score files
     * load the files as score.txt and reset the score as 0
     */
    private void loadScore() {
        try {
            FileInputStream fis = getContext().openFileInput("score.txt");
            Scanner s = new Scanner(fis);
            String lana = s.nextLine();
            score = Integer.parseInt(lana);
            s.close();
        } catch (FileNotFoundException e) {
            score = 0;
        }
    }

    /**
     * setting the pause application and song
     */
    public void onPause() {
        timer.onPause();
        if(Preference.getMusicPref(getContext())) {
            song.pause();
        }
    }

    /**
     * setting the resume application and song
     */
    public void onResume() {
        timer.onResume();
        if(Preference.getMusicPref(getContext())) {
            song.start();
        }
    }

    /**
     * stop the song
     */
    public void stopSong() {
        song.release();
    }
}

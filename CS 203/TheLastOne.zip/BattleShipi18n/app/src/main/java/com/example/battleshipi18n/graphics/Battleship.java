package com.example.battleshipi18n.graphics;

public class Battleship extends Sprite {

    //Todo part 1 to make the singleton design pattern
    private static Battleship battleship;

    private Battleship() {
        /**
         * set the bounds and image for battleship
         */
        /*bounds = new RectF();
        image = BitmapFactory.decodeResource(res, R.drawable.battleship);*/

        super();
        image = ImageCache.getBattleshipImage();
        bounds.set(0,0, image.getWidth(), image.getHeight());
    }

    /**
     * make the getInstance for the battleship for singleton design pattern
     * @return
     */
    public static Battleship getInstance() {
        if(battleship == null) {
            battleship = new Battleship();
        }return battleship;
    }

    @Override
    public void tick() {
        move();
    }


    /*@Override
    protected float relativewidth() {
        return 0.25f;
    }*/

}

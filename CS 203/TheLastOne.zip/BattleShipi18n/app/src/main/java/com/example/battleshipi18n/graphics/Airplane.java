package com.example.battleshipi18n.graphics;

import com.example.battleshipi18n.misc.Size;

public class Airplane extends Enemy {

    private static float minY, maxY;

    /**set random numbers for random picked airplanes
     *
     */
    //Random random = new Random();
    //int n;

    public Airplane() {
        super();
        //this.size = size;
        /**set n as random between 1-3
         *
         */
        /*n = random.nextInt(3);
        if (n == 1) {
            image = BitmapFactory.decodeResource(res, R.drawable.big_airplane);
            size = LARGE;
        } else if (n == 2){
            image = BitmapFactory.decodeResource(res, R.drawable.medium_airplane);
            size = MEDIUM;
        } else {
            image = BitmapFactory.decodeResource(res, R.drawable.little_airplane);
            size = SMALL;
        }*/

        //set the image for size and direction for the picture "collision detection"
        /*image = ImageCache.getAirplaneImage(size, dir);
        bounds.set(0,0,image.getWidth(),image.getHeight());
        // if direction is left to right, it goes from positive, or negative to move right to left
        if(dir == Direction.LEFT_TO_RIGHT) {
            velocity.x = 1;
        } else {
            velocity.x = -1;
        }
        //set the velocity for randomly settings
        //velocity.set(-(float)Math.random()*10-5,0);
        velocity.x = getRandomVelocity();
    }*/
    }

    /**
     * set the position of airplane
     * @param y1
     * @param y2
     */
    public static void setSkyLimits(float y1, float y2) {
        minY = Math.min(y1, y2);
        maxY = Math.max(y1, y2);
    }
    //@Override
    //protected float relativewidth() {
    /**set relative width size
     *
     */
    //   if (size == LARGE) {
     /*       return 0.1f;
        } else if (size == MEDIUM) {
            return 0.08f;
        } else {
            return 0.04f;
        }
    }*/

    /**
     * overrid the move method in sprite class
     */
    /*@Override
    public void move() {
        super.move();

        //if the direction left to right, and if the airplane will be gone from the screen, it returns from left screen
        if (bounds.right < 0) {
            float y = (float)(minY + (maxY-minY)*Math.random());
            reset();
            bounds.offsetTo(ImageCache.screenWidth(), y);

            //if the direction right to left, and if the airplane will be gone from the screen, it returns from right screen
        } else if(bounds.left > ImageCache.screenWidth() + 30) {
            float y = (float)(minY + (maxY-minY)*Math.random());
            reset();
            bounds.offsetTo(0 - image.getWidth(), y);
        }*/

    /**
     * override the tick method
     */
    /*@Override
    public void tick() {
        move();
    }*/

    @Override
    public void explode() {
        super.explode();
        image = ImageCache.getAirplaneExposion();
    }

    @Override
    protected void loadImage() {
        image = ImageCache.getAirplaneImage(size, dir);
        bounds.set(0,0,image.getWidth(), image.getHeight());
    }

    @Override
    protected float getRandomHeight() {
        return (float)(minY + (maxY-minY)*Math.random());
    }

    /**
     * override the reset for the airplane
     */
    @Override
    public void reset() {
        super.reset();
        image = ImageCache.getAirplaneImage(size,dir);
        bounds.set(0 - image.getWidth(),0,image.getWidth(), image.getHeight());
    }

    /**
     * override the getPointValue for correcting point value based on the enemy's size
     * @return
     */
    @Override
    public int getPointValue() {
        if (size == Size.LARGE) {
            return 15;
        } else if (size == Size.MEDIUM) {
            return 20;
        } else {
            return 75;
        }
    }
}

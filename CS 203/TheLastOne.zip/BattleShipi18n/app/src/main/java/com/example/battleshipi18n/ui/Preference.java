package com.example.battleshipi18n.ui;

import android.content.Context;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;

import com.example.battleshipi18n.R;

public class Preference extends PreferenceActivity {

    public static final String MUSIC_PREF = "MUSIC_PREF";
    public static final String FIRE_MISSILES = "MISSILES_PREF";
    public static final String FIRE_DEPTH = "DEPTH_PREF";

    public static final String SPEED_PREF = "SPEED_PREF";
    public static final String NUMBERS_PREF = "NUMBERS_PREF";
    public static final String DIRECTION_PREF = "DIRECTION_PREF";

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        PreferenceScreen screen = getPreferenceManager().createPreferenceScreen(this);
        CheckBoxPreference music = new CheckBoxPreference(this);
        music.setTitle(R.string.music_soundeffect);
        music.setSummaryOn(R.string.music_on);
        music.setSummaryOff(R.string.music_off);
        music.setChecked(true);
        music.setKey(MUSIC_PREF);
        screen.addPreference(music);

        CheckBoxPreference fire_missles = new CheckBoxPreference(this);
        fire_missles.setTitle(R.string.fire_missles);
        fire_missles.setSummaryOn(R.string.fire_missles_on);
        fire_missles.setSummaryOff(R.string.fire_missles_off);
        fire_missles.setChecked(true);
        fire_missles.setKey(FIRE_MISSILES);
        screen.addPreference(fire_missles);


        CheckBoxPreference fire_depth = new CheckBoxPreference(this);
        fire_depth.setTitle(R.string.fire_depth);
        fire_depth.setSummaryOn(R.string.fire_depth_on);
        fire_depth.setSummaryOff(R.string.fire_depth_off);
        fire_depth.setChecked(true);
        fire_depth.setKey(FIRE_DEPTH);
        screen.addPreference(fire_depth);

        //Numbers Preference
        ListPreference number = new ListPreference(this);
        number.setTitle(R.string.enemy_number1);
        number.setSummary(R.string.enemy_number2);
        number.setKey(NUMBERS_PREF);
        String[] number_values = {"1","2","3", "4","5","6","7","8","9","10"};
        number.setEntries(number_values);
        number.setEntryValues(number_values);
        screen.addPreference(number);

        //Speed Preference
        ListPreference speed = new ListPreference(this);
        speed.setTitle(R.string.enemy_speed1);
        speed.setSummary(R.string.enemy_speed2);
        speed.setKey(SPEED_PREF);
        String[] speed_labels = getResources().getStringArray(R.array.speed_options);
        String[] spped_values = {"100", "50", "0"};
        speed.setEntries(speed_labels);
        speed.setEntryValues(spped_values);
        screen.addPreference(speed);

        //Direction Preference
        ListPreference direction = new ListPreference(this);
        direction.setTitle(R.string.enemy_direction1);
        direction.setSummary(R.string.enemy_direction2);
        direction.setKey(DIRECTION_PREF);
        String[] direction_key = getResources().getStringArray(R.array.direction_options);
        String[] direction_values = {"LEFT_to_RIGHT", "RIGHT_to_LEFT", "BOTH"};
        direction.setEntries(direction_key);
        direction.setEntryValues(direction_values);
        screen.addPreference(direction);

        setPreferenceScreen(screen);

    }

    //this is a "facade" method.
    public static boolean getMusicPref(Context c) {
        return PreferenceManager.
                getDefaultSharedPreferences(c).getBoolean(MUSIC_PREF, true);
    }

    public static boolean getFireMissilePref(Context c) {
        return PreferenceManager.
                getDefaultSharedPreferences(c).getBoolean(FIRE_MISSILES, true);
    }

    public static boolean getFireDepthPref(Context c) {
        return PreferenceManager.
                getDefaultSharedPreferences(c).getBoolean(FIRE_DEPTH, true);
    }

    public static int getNumberPref(Context c) {
        String seth = PreferenceManager.
                getDefaultSharedPreferences(c).getString(NUMBERS_PREF, "6");
        return Integer.parseInt(seth);
    }

    public static int getSpeedPref(Context c) {
        String seth = PreferenceManager.
                getDefaultSharedPreferences(c).getString(SPEED_PREF, "0");
        return Integer.parseInt(seth);
    }

    public static String getDirectionPref(Context c) {
        String seth = PreferenceManager.
                getDefaultSharedPreferences(c).getString(DIRECTION_PREF, "BOTH");
        return seth;
    }
}

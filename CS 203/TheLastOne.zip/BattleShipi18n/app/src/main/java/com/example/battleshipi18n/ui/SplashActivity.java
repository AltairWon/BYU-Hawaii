package com.example.battleshipi18n.ui;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.ImageView;

import com.example.battleshipi18n.R;


public class SplashActivity extends Activity {

    private ImageView iv;

    /**
     * put the splash screen on the device
     * @param b
     */
    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        iv = new ImageView(this);
        iv.setImageResource(R.drawable.splash);
        iv.setScaleType(ImageView.ScaleType.FIT_XY);
        setContentView(iv);
    }

    @Override
    public boolean onTouchEvent(MotionEvent m) {
        float w = iv.getWidth();
        float h = iv.getHeight();
        RectF prefsButton = new RectF(5,5,5+(w*0.1f),5+(h*0.1f));
        RectF startButton = new RectF(w/2.6f, h/2, w, h);
        RectF aboutButton = new RectF(5.0f,h-5.0f-(h*0.1f),5+(w*0.1f),h-5.0f);
        if (m.getAction() == MotionEvent.ACTION_DOWN) {
            float x = m.getX();
            float y = m.getY();

            if (prefsButton.contains(x,y)) {
                Intent lana = new Intent(this, Preference.class);
                startActivity(lana);
            }
            if (startButton.contains(x,y)) {
                Intent marco = new Intent(this, MainActivity.class);
                startActivity(marco);
            }
            if (aboutButton.contains(x,y)) {
                AlertDialog.Builder ab = new AlertDialog.Builder(iv.getContext());
                ab.setTitle(R.string.about_box)
                        .setMessage(R.string.about_battleship)
                        .setCancelable(true);
                AlertDialog box = ab.create();
                box.show();
            }
        }
        return true;
    }



}

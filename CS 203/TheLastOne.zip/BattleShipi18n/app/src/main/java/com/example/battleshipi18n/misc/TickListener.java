package com.example.battleshipi18n.misc;

public interface TickListener {

    void tick();

}

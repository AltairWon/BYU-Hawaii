package com.example.battleshipi18n.misc;

import android.os.Handler;
import android.os.Message;

import java.util.ArrayList;
import java.util.List;

public class Timer extends Handler {
    private List<TickListener> tickListeners;
    //set the pause as bollean
    private boolean paused;
    boolean altair;

    public Timer() {
        altair = true;
        tickListeners = new ArrayList<>();
        //set basicly pause as false
        paused = false;
        sendMessageDelayed(obtainMessage(), 0);
    }


    /*public void pause() {
        paused = true;

    }

    public void unpause() {
        paused = false;
        sendMessageDelayed(obtainMessage(),50);

    }*/
    /**
     * set the movement for all objects
     * @param msg
     */
    @Override
    public void handleMessage(Message msg) {
        for(TickListener t: tickListeners){
            t.tick();
        }
        //if paused is true, tickListeners are clear
        if (paused == true) {
            tickListeners.clear();
        }
        if(altair == true){
        sendMessageDelayed(obtainMessage(), 100);
        }
    }

    /**
     * subscribe for the adding tick to move
     * @param tick
     */
    public void subscribe(TickListener tick) {
        tickListeners.add(tick);
    }

    /**
     * remove the objects
     * @param tick
     */
    public void unsubscribe(TickListener tick) {
        tickListeners.remove(tick);
    }

    /**
     * set paused for all objects
     * @param st
     */
    public void setPaused(boolean st) {
        paused = st;
    }

    /**
     * set the pause moment for application
     */
    public void onPause() {
        altair = false;

    }

    /**
     * set the resume moment for application
     */
    public void onResume() {
        altair = true;
        sendMessageDelayed(obtainMessage(), 0);
    }
}

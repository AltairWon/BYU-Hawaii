package com.example.battleshipi18n.graphics;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.example.battleshipi18n.R;
import com.example.battleshipi18n.misc.Direction;
import com.example.battleshipi18n.misc.Size;

/**
 * set the all objects from view class
 */
public class ImageCache {
    private static float screenWidth, screenHeight;
    private static Bitmap battleship;
    private static Bitmap water;
    private static Bitmap airplane_small_left2right;
    private static Bitmap airplane_med_left2right;
    private static Bitmap airplane_big_left2right;
    private static Bitmap airplane_small_right2left;
    private static Bitmap airplane_med_right2left;
    private static Bitmap airplane_big_right2left;
    private static Bitmap submarine_small_left2right;
    private static Bitmap submarine_med_left2right;
    private static Bitmap submarine_big_left2right;
    private static Bitmap submarine_small_right2left;
    private static Bitmap submarine_med_right2left;
    private static Bitmap submarine_big_right2left;
    private static Bitmap depth_charge;
    private static Bitmap explosion_submarine;
    private static Bitmap explosion_airplane;
    private static Bitmap pop;


    /**
     * make the init for resources pictures
     * @param res
     * @param w
     * @param h
     */
    public static void init(Resources res, float w, float h) {
        screenWidth = w;
        screenHeight = h;
        battleship = loadAndScale(res, R.drawable.battleship, w*0.21f);
        water = loadAndScale(res, R.drawable.water, w*0.09f);
        airplane_small_left2right = loadAndScale(res, R.drawable.little_airplane_flip, w*0.05f);
        airplane_med_left2right = loadAndScale(res, R.drawable.medium_airplane_flip, w*0.083f);
        airplane_big_left2right = loadAndScale(res, R.drawable.big_airplane_flip, w*0.12f);
        airplane_small_right2left = loadAndScale(res, R.drawable.little_airplane, w*0.02f);
        airplane_med_right2left = loadAndScale(res, R.drawable.medium_airplane, w*0.06f);
        airplane_big_right2left = loadAndScale(res, R.drawable.big_airplane, w*0.09f);
        submarine_small_left2right = loadAndScale(res, R.drawable.little_submarine, w*0.02f);
        submarine_med_left2right = loadAndScale(res, R.drawable.medium_submarine, w*0.06f);
        submarine_big_left2right = loadAndScale(res, R.drawable.big_submarine, w*0.09f);
        submarine_small_right2left = loadAndScale(res, R.drawable.little_submarine_flip, w*0.05f);
        submarine_med_right2left = loadAndScale(res, R.drawable.medium_submarine_flip, w*0.083f);
        submarine_big_right2left = loadAndScale(res, R.drawable.big_submarine_flip, w*0.1f);
        depth_charge = loadAndScale(res, R.drawable.depth_charge, w*0.02f);
        pop = loadAndScale(res, R.drawable.star, w*0.01f);
        explosion_airplane = loadAndScale(res, R.drawable.airplane_explosion, w*0.12f);
        explosion_submarine = loadAndScale(res, R.drawable.submarine_explosion, w*0.12f);
    }

    /**
     * settinf the load and scale
     * @param res
     * @param id
     * @param newWidth
     * @return
     */
    private static Bitmap loadAndScale(Resources res, int id, float newWidth) {
        Bitmap original = BitmapFactory.decodeResource(res, id);
        float aspectRatio = (float)original.getHeight()/(float)original.getWidth();
        float newHeight = newWidth * aspectRatio;
        return Bitmap.createScaledBitmap(original, (int)newWidth, (int)newHeight, true);
    }

    /**
     * set the airplane image of size and direction
     * @param s
     * @param d
     * @return
     */
    public static Bitmap getAirplaneImage(Size s, Direction d) {
        if (d==Direction.LEFT_TO_RIGHT) {
            if (s==Size.LARGE) {
                return airplane_big_left2right;
            } else if (s==Size.MEDIUM) {
                return airplane_med_left2right;
            } else {
                return airplane_small_left2right;
            }
        } else {
            if (s==Size.LARGE) {
                return airplane_big_right2left;
            } else if (s==Size.MEDIUM) {
                return airplane_med_right2left;
            } else {
                return airplane_small_right2left;
            }
        }
    }

    /**
     * set the submarine image for size and direction
     * @param s
     * @param d
     * @return
     */
    public static Bitmap getSubmarineImage(Size s, Direction d) {
        if (d==Direction.LEFT_TO_RIGHT) {
            if (s==Size.LARGE) {
                return submarine_big_left2right;
            } else if (s==Size.MEDIUM) {
                return submarine_med_left2right;
            } else {
                return submarine_small_left2right;
            }
        } else {
            if (s==Size.LARGE) {
                return submarine_big_right2left;
            } else if (s==Size.MEDIUM) {
                return submarine_med_right2left;
            } else {
                return submarine_small_right2left;
            }
        }
    }

    /**
     * set the water image
     * @return
     */
    public static Bitmap getWaterImage() {
        return water;
    }

    /**
     * set the battleship image
     * @return
     */
    public static Bitmap getBattleshipImage() {
        return battleship;
    }

    /**
     * set the depthcharge image
     * @return
     */
    public static Bitmap getDepthChargeImage() {
        return depth_charge;
    }

    /**
     * set the explosion of submarine
     * @return
     */
    public static Bitmap getSubmarineExplosion() {
        return explosion_submarine;
    }

    /**
     * set the explosion of airplane
     * @return
     */
    public static Bitmap getAirplaneExposion() {
        return explosion_airplane;
    }

    /**
     * set the cannon star image
     * @return
     */
    public static Bitmap getCannonFire() { return pop; }

    /**
     * set the screenWidth of all objects
     * @return
     */
    public static float screenWidth() {
        return screenWidth;
    }

    /**
     * set the screenHeight of all objects
     * @return
     */
    public static float screenHeight() {
        return screenHeight;
    }

}

package com.example.battleshipi18n.graphics;


import android.graphics.Canvas;

import com.example.battleshipi18n.misc.Direction;
import com.example.battleshipi18n.misc.Size;

public abstract class Enemy extends Sprite {

    protected Size size;
    //add the Direction field type
    protected Direction dir;
    protected boolean explorer;
    private static int speedPrefer;
    private static String directionPrefer;

    /**
     * set the enemy class
     */
    public Enemy() {
        // set the random size for objects of enemy
        super();
        explorer = false;
        reset();

        /*double r = Math.random();
        if (r<0.333) {
            size = Size.SMALL;
        } else if (r<0.6667) {
            size = Size.MEDIUM;
        } else {
            size = Size.LARGE;
        }

        //set direction randomly for the showing after exploding
        r = Math.random();
        if(r < 0.5) {
            dir = Direction.LEFT_TO_RIGHT;
        } else {
            dir = Direction.RIGHT_TO_LEFT;
        }*/
    }

    public static void setPreference(int i, String s) {
        speedPrefer = i;
        directionPrefer = s;
    }

    /**
     * override the move in the sprite class
     */
    @Override
    public void move() {
        super.move();
        if(Math.random() < 0.1) {
            velocity.x = getRandomVelocity();
        }

        if(bounds.right <0 || bounds.left > ImageCache.screenWidth()) {
            reset();
        }
    }

    /**
     * add method for the random velocity
     */
    protected float getRandomVelocity() {
        /*if (Math.random() < 0.1) {
            float v = (float)((Math.random() * 27+5) * Math.signum(velocity.x));
            velocity.set(v,0);

        }*/
        return (float)(((Math.random() * 0.00625 * ImageCache.screenWidth()) * Math.signum(velocity.x)) + ((float)speedPrefer * Math.signum(velocity.x)));
    }

    /**
     * make the explode method for the in case of the exploding
     */
    public void explode() {
        //instanceof  = if this object is airplane
        /*if(this instanceof Airplane) {
            this.image = ImageCache.getAirplaneExposion();
        } // else = if this object is submarine
        else {
            this.image = ImageCache.getSubmarineExplosion();
        }*/
        //explorer is true to let the explorer knows the objects of enemies will be exploded
        explorer = true;
        //set velocity for 0,0 because it should not move the explode
        velocity.set(0,0);
    }

    /**
     * set the exploding to set to true inside the explode() method
     * to get the exploding the explorer. reset() sets "exploding" back to false.
     * @return
     */
    public boolean exploding() {return explorer;}


    /**
     * set the explorer false
     */
    public void setexplode() {explorer = false;}

    /**
     * load the image after reset
     */
    protected abstract void loadImage();

    /**
     * set the random height
     */
    protected  abstract float getRandomHeight();


    /**
     * set the reset if the missile hits planes, or the depthcharge hits submarines
     */
    public void reset() {
        double r1 = Math.random();
        double r2 = Math.random();
        //Direction newDirection;
        //Size newSize;
        if(directionPrefer.equals("LEFT_to_RIGHT")){
            dir = Direction.LEFT_TO_RIGHT;
        } else if(directionPrefer.equals("RIGHT_to_LEFT")) {
            dir = Direction.RIGHT_TO_LEFT;
        } else {
            if (r1 < 0.5) {
                dir = Direction.RIGHT_TO_LEFT;
            } else {
                dir = Direction.LEFT_TO_RIGHT;
            }
        }
        if (r2 < 0.3333) {
            size = Size.LARGE;
        } else if (r2 < 0.667) {
            size = Size.MEDIUM;
        } else {
            size = Size.SMALL;
        }
        loadImage();
        //reset(newSize, newDirection);
        if (dir == Direction.RIGHT_TO_LEFT) {
            velocity.x = -1;
            velocity.x = getRandomVelocity();
            bounds.offsetTo(ImageCache.screenWidth()-1, getRandomHeight());
        } else {
            velocity.x = 1;
            velocity.x = getRandomVelocity();
            bounds.offsetTo(-image.getWidth()+1, getRandomHeight());
        }
    }


    @Override
    public void draw(Canvas c) {
        super.draw(c);
        if(explorer) {
            explorer = false;
            reset();

        }
    }
    /**
     * make abstract method for get point value
     * @return
     */
    public abstract int getPointValue();


}



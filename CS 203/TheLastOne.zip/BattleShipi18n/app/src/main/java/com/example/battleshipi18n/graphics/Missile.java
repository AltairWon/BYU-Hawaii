package com.example.battleshipi18n.graphics;


import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;

import com.example.battleshipi18n.graphics.Sprite;
import com.example.battleshipi18n.misc.Direction;


public class Missile extends Sprite {
    private Direction direction;
    private Paint missilePaint;

    /**
     * make the velocity of the left and right
     * @param d
     */
    public Missile(Direction d) {
        direction = d;
        missilePaint = new Paint();
        missilePaint.setColor(Color.DKGRAY);
        missilePaint.setStyle(Paint.Style.STROKE);
        final float w = ImageCache.screenWidth();
        float newWidth = w * 0.05f;
        float newHeight = newWidth;
        //bounds = new RectF(0f,0f,50f,50f);
        bounds.set(0,0,newWidth, newWidth);
        missilePaint.setStrokeWidth(w*0.0025f);
        final float fire = 25f;
        if (direction == Direction.LEFT_TO_RIGHT) {
            velocity = new PointF(w/fire, -w/fire);
        }
        if (direction == Direction.RIGHT_TO_LEFT) {
            velocity = new PointF(-w/fire,-w/fire);

        }

    }

    /**
     * scale for the missle
     * @param w
     */
    /*@Override
    public void scale(float w) {
        float width = w * relativewidth();
        bounds.set(0,0,width,width);

    }*/

    /**
     * setting the postion of the missile for left to right and right to left
     * @param x
     * @param y
     */
    @Override
    public void setPosition(float x,float y) {
        if (direction == Direction.LEFT_TO_RIGHT) {
            bounds.offsetTo(x,y);
        }
        if (direction == Direction.RIGHT_TO_LEFT) {
            bounds.offsetTo(x,y);

        }
    }

    /**
     * scale the relativewidth
     * @return
     */
    /*@Override
    protected float relativewidth() {
        return 0.3f;
    }

     */

    /**
     * draw the line of the left to right and right to left
     * @param c
     */
    @Override
    public void draw(Canvas c) {
        if (direction == Direction.LEFT_TO_RIGHT) {
            c.drawLine(bounds.left, bounds.bottom, bounds.right, bounds.top, paint);
        }
        if(direction == Direction.RIGHT_TO_LEFT) {
            c.drawLine(bounds.right, bounds.bottom, bounds.left, bounds.top, paint);
        }
    }

    /**
     * override the tick method
     */
    @Override
    public void tick() {
        move();
    }
}

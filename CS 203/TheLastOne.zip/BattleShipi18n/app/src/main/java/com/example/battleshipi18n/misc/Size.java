package com.example.battleshipi18n.misc;

public enum Size {
    SMALL,
    MEDIUM,
    LARGE
}
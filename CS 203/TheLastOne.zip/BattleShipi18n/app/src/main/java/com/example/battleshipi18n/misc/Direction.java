package com.example.battleshipi18n.misc;

public enum Direction {
    LEFT_TO_RIGHT,
    RIGHT_TO_LEFT
}

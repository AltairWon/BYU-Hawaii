package com.example.battleshipi18n.graphics;

import com.example.battleshipi18n.graphics.Enemy;
import com.example.battleshipi18n.misc.Direction;
import com.example.battleshipi18n.misc.Size;

public class Submarine extends Enemy {
    private static float minY, maxY;

    /**set random numbers for random picked submarines
     *
     */

    public Submarine() {
        super();
        /*n = random.nextInt(3);
            if (n == 1) {
                image = BitmapFactory.decodeResource(res, R.drawable.big_submarine);
                size = LARGE;
            } else if (n == 2){
                image = BitmapFactory.decodeResource(res, R.drawable.medium_submarine);
                size = MEDIUM;
            } else {
                image = BitmapFactory.decodeResource(res, R.drawable.little_submarine);
                size = SMALL;
            }*/
        image = ImageCache.getSubmarineImage(size, dir);
        bounds.set(0,0,image.getWidth(), image.getHeight());
        //set the velocity for the randomly settings
        if(dir == Direction.LEFT_TO_RIGHT) {
            velocity.x = 1;
        } else {
            velocity.x = -1;
        }
        velocity.x = getRandomVelocity();
    }

        /*@Override
        protected float relativewidth() {
            if (size == LARGE) {
                return 0.1f;
            } else if (size == MEDIUM) {
                return 0.08f;
            } else {
                return 0.04f;
            }
        }*/

    /**
     * set the waterdepth for setting the position of submarine
     * @param y1
     * @param y2
     */
    public static void setWaterDepth(float y1, float y2) {
        minY = Math.min(y1,y2);
        maxY = Math.max(y1,y2);
    }
    /**
     * override the move method in the sprite class
     */
    @Override
    public void move() {
        super.move();

        //if the direction left to right, and if the airplane will be gone from the screen, it returns from left screen
        if (bounds.right < 0) {
            float y = (float) (minY + (maxY - minY) * Math.random());
            reset();
            bounds.offsetTo(ImageCache.screenWidth(), y);

            //if the direction right to left, and if the airplane will be gone from the screen, it returns from right screen
        } else if (bounds.left > ImageCache.screenWidth()) {
            float y = (float) (minY + (maxY - minY) * Math.random());
            reset();
            bounds.offsetTo(0 - image.getWidth(), y);
        }
        if (bounds.top < ImageCache.screenHeight() / 2) {
            bounds.offsetTo(bounds.left, (float) (minY + (maxY - minY) * Math.random()));
        }
    }

    /**
     * override the tick method
     */
    /*@Override
    public void tick() {
        move();
    }*/

    @Override
    public void explode() {
        super.explode();
        image = ImageCache.getSubmarineExplosion();
    }

    @Override
    protected void loadImage() {
        image = ImageCache.getSubmarineImage(size, dir);
        bounds.set(0,0,image.getWidth(),image.getHeight());
    }

    @Override
    protected float getRandomHeight() {
        return (float)(minY + (maxY-minY)*Math.random());
    }

    /**
     * override the reset for resetting the submarine
     */
    @Override
    public void reset() {
        super.reset();
        image = ImageCache.getSubmarineImage(size,dir);
        bounds.set(0 - image.getWidth(),0,image.getWidth(), image.getHeight());
    }

    /**
     * override the getPointValue for correcting point value based on the enemy's size
     * @return
     */
    @Override
    public int getPointValue() {
        if (size == Size.LARGE) {
            return 25;
        } else if (size == Size.MEDIUM) {
            return 40;
        } else {
            return 150;
        }
    }


}

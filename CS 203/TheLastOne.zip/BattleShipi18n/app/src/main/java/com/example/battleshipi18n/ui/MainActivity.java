package com.example.battleshipi18n.ui;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {

    private Mockup mockup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mockup = new Mockup(this);
        setContentView(mockup);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mockup.stopSong();
        mockup.saveScore();
    }

    @Override
    public void onPause() {
        super.onPause();
        mockup.onPause();

    }

    @Override
    public void onResume() {
        super.onResume();
        mockup.onResume();
    }

}

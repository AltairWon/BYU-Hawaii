package com.example.battleship.Subclass;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;

import com.example.battleship.R;
import com.example.battleship.Sprite.Airplane;
import com.example.battleship.Sprite.Battleship;
import com.example.battleship.Sprite.DepthCharge;
import com.example.battleship.Sprite.Direction;
import com.example.battleship.Sprite.ImageCache;
import com.example.battleship.Sprite.Missile;
import com.example.battleship.Sprite.Star;
import com.example.battleship.Sprite.Submarine;
import com.example.battleship.Sprite.TickListener;
import com.example.battleship.Sprite.Timer;

import java.util.ArrayList;
import java.util.List;

public class Mockup extends View implements TickListener {

    private Battleship battleship;
    private Airplane plane1;
    private Airplane plane2;
    private Airplane plane3;
    private Submarine sub1, sub2, sub3;
    private List<DepthCharge> charges;
    private List<Missile> missiles;
    private List<Star> star;
    private Bitmap water;
    private boolean init;
    private Timer timer;

    @Override
    public void tick() {
        invalidate();
    }


    public Mockup(Context c) {
        super(c);
        init = false;
        /**instantiate all classes
         *
         */
        //battleship = new Battleship(getResources());
        //plane1 = new Airplane(getResources());
        //plane2 = new Airplane(getResources());
        //plane3 = new Airplane(getResources());
        //sub1 = new Submarine(getResources());
        //sub2 = new Submarine(getResources());
        //sub3 = new Submarine(getResources());
        charges = new ArrayList<>();
        missiles = new ArrayList<>();
        star = new ArrayList<>();
        timer = new Timer();
        /**make water constructor
         *
         */
        //water = BitmapFactory.decodeResource(getResources(), R.drawable.water);
    }

    /**
     * make the scale and position of all objects
     * @param c
     */
    @Override
    public void onDraw(Canvas c) {
        float w = c.getWidth();
        float h = c.getHeight();
        if (init == false) {
            init = true;
            ImageCache.init(getResources(),w,h);
            timer.subscribe(this);

            /**set battleship's scale size and position
             *
             */
            //battleship.scale(w);
            battleship = new Battleship();
            battleship.setPosition(w/2, h/2.38f);
            /**set airplanes' scales and positions
             *
             */
            //plane1.scale(w);
            plane1 = new Airplane();
            timer.subscribe(plane1);

            plane1.getHeight(h);
            plane1.setPosition(w/5, h/3.5f);
            //plane2.scale(w);
            plane2 = new Airplane();
            timer.subscribe(plane2);

            plane2.getHeight(h);
            plane2.setPosition(w/1.8f, h/8.9f);
            //plane3.scale(w);
            plane3 = new Airplane();
            timer.subscribe(plane3);

            plane3.getHeight(h);
            plane3.setPosition(w/1.2f, h/5.4f);
            /**set submarines' scales and positions
             *
             */
            //sub1.scale(w);
            sub1 = new Submarine();
            timer.subscribe(sub1);

            sub1.getHeight(h);
            sub1.setPosition(w/5, h/1.1f);
            //sub2.scale(w);
            sub2 = new Submarine();
            timer.subscribe(sub2);

            sub2.getHeight(h);
            sub2.setPosition(w/2, h/1.7f);
            //sub3.scale(w);
            sub3 = new Submarine();
            timer.subscribe(sub3);

            sub3.getHeight(h);
            sub3.setPosition(w/1.1f, h/1.4f);
            /**set water scale size
             *
             */

            water = ImageCache.getWaterImage();
            /*float waterSize1 = w *0.17f;
            float waterSize2 = h *0.03f;
            water = Bitmap.createScaledBitmap(water,
                    (int)waterSize1, (int)waterSize2, true);*/

        }
        /**make background for white color
         *
         */
        c.drawColor(Color.WHITE);
        /**set water
         *
         */
        float waterPosX = w/6;
        float waterPosY = h/2 - water.getHeight();
        c.drawBitmap(water, 0, waterPosY, null);
        c.drawBitmap(water, waterPosX, waterPosY, null);
        c.drawBitmap(water, waterPosX * 2, waterPosY,null);
        c.drawBitmap(water, waterPosX * 3, waterPosY, null);
        c.drawBitmap(water, waterPosX * 4, waterPosY, null);
        c.drawBitmap(water, waterPosX * 5, waterPosY, null);
        c.drawBitmap(water, waterPosX * 6, waterPosY, null);
        /**draw battleship, airplanes, and submarines
         *
         */
        battleship.draw(c);
        plane1.draw(c);
        plane2.draw(c);
        plane3.draw(c);
        sub1.draw(c);
        sub2.draw(c);
        sub3.draw(c);

        for (DepthCharge d : charges) {
            d.draw(c);
        }

        for (Missile m : missiles) {
            m.draw(c);
        }

        ArrayList<Star> tresh = new ArrayList<>();
        for (Star s : star) {
            if (s.getDisappear() == false){
                s.draw(c);
            } else  {
                tresh.add(s);
            }
        }

        for (Star st : tresh) {
            star.remove(st);

        } tresh.clear();
    }

    /**
     *  make the onTouch Event
     * @param m
     * @return
     */
    @Override
    public boolean onTouchEvent(MotionEvent m) {
        float x = m.getX();
        float y = m.getY();
        List<Missile> mis;
        mis = new ArrayList<Missile>();
        List<DepthCharge> doomed = new ArrayList<>();
        if (m.getAction() == MotionEvent.ACTION_DOWN) {
            if (y > getHeight() / 2) {
                DepthCharge ch = new DepthCharge();
                timer.subscribe(ch);
                ch.setPosition(getWidth() / 2, getHeight() / 2);
                charges.add(ch);
            } else {
                Missile mi;
                Star st;
                if (x < getWidth() / 2) {
                    mi = new Missile(Direction.RIGHT_TO_LEFT);
                    mi.setPosition(getWidth() * 0.34f, getHeight() * 0.3f);
                    st = new Star(getResources(), Direction.RIGHT_TO_LEFT);
                    st.setPosition(getWidth()*0.34f, getHeight()*0.3f);

                } else {
                    mi = new Missile(Direction.LEFT_TO_RIGHT);
                    mi.setPosition(getWidth() * 0.64f, getHeight() * 0.3f);
                    st = new Star(getResources(), Direction.LEFT_TO_RIGHT);
                    st.setPosition(getWidth()*0.64f, getHeight()*0.3f);

                }
                missiles.add(mi);
                timer.subscribe(mi);
                star.add(st);
            }
        }
        for (DepthCharge d : charges) {
            if (d.getTop() > getHeight()) {
                doomed.add(d);
                timer.unsubscribe(d);

            }
        }

        for (DepthCharge d : doomed) {
            charges.remove(d);
        }
        doomed.clear();


        for (Missile mi : missiles) {
            if (mi.getBottom() < 0) {
                mis.add(mi);
                timer.unsubscribe(mi);
            }
        }

        for (Missile ms : mis) {
            missiles.remove(ms);
        }
        mis.clear();

        return true;
    }
}

package com.example.battleship.Sprite;

public enum Size {
    SMALL,
    MEDIUM,
    LARGE
}
package com.example.battleship.Sprite;

import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

import com.example.battleship.R;

public class Battleship extends Sprite {

    public Battleship() {
        /**
         * set the bounds and image for battleship
         */
        /*bounds = new RectF();
        image = BitmapFactory.decodeResource(res, R.drawable.battleship);*/

        super();
        image = ImageCache.getBattleshipImage();
        bounds.set(0,0, image.getWidth(), image.getHeight());
    }

    @Override
    public void tick() {
        move();
    }


    /*@Override
    protected float relativewidth() {
        return 0.25f;
    }*/

}

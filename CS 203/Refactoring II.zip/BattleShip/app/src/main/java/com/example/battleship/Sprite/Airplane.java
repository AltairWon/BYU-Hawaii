package com.example.battleship.Sprite;

import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

import com.example.battleship.R;

import java.util.Random;

import static com.example.battleship.Sprite.Size.*;

public class Airplane extends Enemy {

    /**set random numbers for random picked airplanes
     *
     */
    Random random = new Random();
    int n;
    private Size size;

    public Airplane() {
        super();
        bounds = new RectF();
        this.size = size;
        /**set n as random between 1-3
         *
         */
        /*n = random.nextInt(3);
        if (n == 1) {
            image = BitmapFactory.decodeResource(res, R.drawable.big_airplane);
            size = LARGE;
        } else if (n == 2){
            image = BitmapFactory.decodeResource(res, R.drawable.medium_airplane);
            size = MEDIUM;
        } else {
            image = BitmapFactory.decodeResource(res, R.drawable.little_airplane);
            size = SMALL;
        }*/
        image = ImageCache.getAirplaneImage(size, Direction.RIGHT_TO_LEFT);

        //set the velocity for randomly settings
        velocity.set(-(float)Math.random()*10-5,0);
    }

    //@Override
    //protected float relativewidth() {
        /**set relative width size
         *
         */
     //   if (size == LARGE) {
     /*       return 0.1f;
        } else if (size == MEDIUM) {
            return 0.08f;
        } else {
            return 0.04f;
        }
    }*/

    /**
     * overrid the move method in sprite class
     */
    @Override
    public void move() {
        super.move();
        if (bounds.right < 0) {
            bounds.offsetTo(ImageCache.screenWidth(), (float) Math.random()* ImageCache.screenHeight()/4);
        }


    }

    @Override
    public void tick() {
        move();
    }
}

package com.example.battleship.Sprite;

public interface TickListener {

    void tick();

}

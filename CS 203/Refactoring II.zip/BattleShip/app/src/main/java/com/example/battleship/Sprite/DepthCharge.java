package com.example.battleship.Sprite;

import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

import com.example.battleship.R;

public class DepthCharge extends Sprite {

    /**
     * make the image for depth charge and velocity
     * @param
     */
    public DepthCharge() {
        super();
        bounds = new RectF();
        //image = BitmapFactory.decodeResource(res, R.drawable.depth_charge);
        image = ImageCache.getDepthChargeImage();
        velocity.x = 0;
        velocity.y = 50;
    }

    @Override
    public void tick() {
        move();
    }

    /**
     * make the relativewidth
     * @return
     */
    /*@Override
    protected float relativewidth() {
        return 0.03f;
    }
     */
}

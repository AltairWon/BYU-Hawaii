package com.example.battleship.Subclass;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Mockup mockup = new Mockup(this);
        setContentView(mockup);
    }
}

package com.example.battleship.Sprite;

public enum Direction {
    LEFT_TO_RIGHT,
    RIGHT_TO_LEFT
}

package com.example.battleship.Sprite;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;

public abstract class Sprite implements TickListener{
    /**set bitmap and rectf
     *
     */
    protected Bitmap image;
    protected RectF bounds;
    protected PointF velocity;
    protected float screenWidth;
    protected float screeHeight;
    protected Paint paint;

    public Sprite() {

        velocity = new PointF();
        paint = new Paint();
        bounds = new RectF();
    }

    /**set relative width
     *
     * @return
     */
    //protected abstract float relativewidth();

    /**
     * make the scale structure for screen width
     * @param w
     */
    /*public void scale(float w) {
        screenWidth = w;
        float scaleWidth = screenWidth * relativewidth();
        float scaleHeight = scaleWidth * ((float)image.getHeight()/(float)image.getWidth());
        image = Bitmap.createScaledBitmap(image, (int)scaleWidth, (int)scaleHeight,true);
        bounds.set(0,0, scaleWidth, scaleWidth);
    }*/

    /**
     * make the set position for the x and y for subclasses
     * @param x
     * @param y
     */
    public void setPosition(float x, float y) {
        bounds.offsetTo(x-image.getWidth()/2,y-image.getHeight()/2);

    }

    /**
     * make draw structure for drawing the subclasses
     * @param c
     */
    public void draw(Canvas c) {
        c.drawBitmap(image, bounds.left, bounds.top, paint);
    }

    /**
     * add the move method for moving the objects
     */
    public void move() {

        bounds.offset(velocity.x, velocity.y);
    }

    /**
     * add the screenHeight for setting Height
     * @param screenHeight
     */

    public void getHeight(float screenHeight) {
           this.screeHeight = screenHeight;
    }

    /**
     * setting the get top
     * @return
     */
    public float getTop() {
        return bounds.top; }

    /**
     * setting the get bottom
     * @return
     */
    public float getBottom() {
        return bounds.bottom;}

}
    
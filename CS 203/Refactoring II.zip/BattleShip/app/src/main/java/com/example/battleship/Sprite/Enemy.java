package com.example.battleship.Sprite;


public abstract class Enemy extends Sprite {

    /**
     * set the enemy class
     */
    public Enemy() {
        super();
    }

    /**
     * override the move in the sprite class
     */
    @Override
    public void move() {
        super.move();
        getRandomVelocity();
        }

    /**
     * add method for the random velocity
     */
    public void getRandomVelocity() {
        if (Math.random() < 0.1) {
            float v = (float)((Math.random() * 27+5) * Math.signum(velocity.x));
            velocity.set(v,0);

        }
    }
}



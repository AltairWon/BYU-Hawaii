package com.example.battleship.Sprite;

import android.os.Handler;
import android.os.Message;

import java.util.ArrayList;
import java.util.List;

public class Timer extends Handler {
    private List<TickListener> tickListeners;

    public Timer() {
        tickListeners = new ArrayList<>();
        sendMessageDelayed(obtainMessage(0), 50);
    }

    /**
     * set the movement for all objects
     * @param msg
     */
    @Override
    public void handleMessage(Message msg) {
        for(TickListener t:tickListeners){
            t.tick();
        }

        sendMessageDelayed(obtainMessage(0), 100);

    }

    public void subscribe(TickListener tick) {
        tickListeners.add(tick);
    }

    public void unsubscribe(TickListener tick) {
        tickListeners.remove(tick);
    }
}

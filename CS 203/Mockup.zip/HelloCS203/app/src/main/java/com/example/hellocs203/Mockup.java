package com.example.hellocs203;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.View;

public class Mockup extends View {

    private Bitmap battleship;
    private Bitmap bigairplane;
    private Bitmap mediumairplane;
    private Bitmap littleairplane;
    private Bitmap bigsubmarine;
    private Bitmap mediumsubmarine;
    private Bitmap littlesubmarine;
    private Bitmap water;


    private boolean init;


    public Mockup(Context c) {
        super(c);
        init = false;
        battleship = BitmapFactory.decodeResource(getResources(), R.drawable.battleship);
        bigairplane = BitmapFactory.decodeResource(getResources(),R.drawable.big_airplane);
        mediumairplane = BitmapFactory.decodeResource(getResources(),R.drawable.medium_airplane);
        littleairplane = BitmapFactory.decodeResource(getResources(),R.drawable.little_airplane);
        bigsubmarine = BitmapFactory.decodeResource(getResources(),R.drawable.big_submarine);
        mediumsubmarine = BitmapFactory.decodeResource(getResources(),R.drawable.medium_submarine);
        littlesubmarine = BitmapFactory.decodeResource(getResources(),R.drawable.little_submarine);
        water = BitmapFactory.decodeResource(getResources(),R.drawable.water);
    }

    @Override
    public void onDraw(Canvas c) {
        float w = c.getWidth();
        float h = c.getHeight();
        if (init == false) {

            //make size for ship
            float shipSize1 = w * 0.3f;
            float shipSize2 = h *0.1f;
            battleship = Bitmap.createScaledBitmap(battleship,
                    (int)shipSize1, (int)shipSize2, true);
            //make size for big airplane
            float bigairplaneSize1 = w * 0.1f;
            float bigairplaneSize2 = h * 0.05f;
            bigairplane = Bitmap.createScaledBitmap(bigairplane,
                    (int)bigairplaneSize1, (int)bigairplaneSize2, true);
            //make size for medium airplane
            float mediumairplanSize1 = w * 0.08f;
            float mediumairplanSize2 = h * 0.06f;
            mediumairplane = Bitmap.createScaledBitmap(mediumairplane,
                    (int)mediumairplanSize1, (int)mediumairplanSize2, true);
            //make size for little airplane
            float littleairplanSize1 = w * 0.04f;
            float littleairplanSize2 = h * 0.06f;
            littleairplane = Bitmap.createScaledBitmap(littleairplane,
                    (int)littleairplanSize1, (int)littleairplanSize2, true);
            //make size for big submarine
            float bigsubmarineSize1 = w * 0.1f;
            float bigsubmarineSize2 = h * 0.05f;
            bigsubmarine = Bitmap.createScaledBitmap(bigsubmarine,
                    (int)bigsubmarineSize1, (int)bigsubmarineSize2, true);
            //make size for medium submarine
            float mediumsubmarineSize1 = w * 0.08f;
            float mediumsubmarineSize2 = h * 0.06f;
            mediumsubmarine =  Bitmap.createScaledBitmap(mediumsubmarine,
                    (int)mediumsubmarineSize1, (int)mediumsubmarineSize2, true);
            //make size for little submarine
            float littlesubmarineSize1 = w * 0.04f;
            float littlesubmarineSIze2 = h * 0.04f;
            littlesubmarine = Bitmap.createScaledBitmap(littlesubmarine,
                    (int)littlesubmarineSize1, (int)littlesubmarineSIze2, true);
            //make size for water
            float waterSize1 = w *0.17f;
            float waterSize2 = h *0.03f;
            water = Bitmap.createScaledBitmap(water,
                    (int)waterSize1, (int)waterSize2, true);


            init = true;
        }
        //make background for white color
        c.drawColor(Color.WHITE);
        //set big airplane
        float bigairPosx = (float) (w/1.5 -bigairplane.getWidth()/5);
        float bigairPosY = h/8 - bigairplane.getHeight();
        c.drawBitmap(bigairplane, bigairPosx, bigairPosY, null);
        //set medium airplane
        float mediumairPosX = w/3 - mediumairplane.getWidth()/3;
        float meduumairPosY = h/3 - mediumairplane.getHeight();
        c.drawBitmap(mediumairplane, mediumairPosX, meduumairPosY, null);
        //set little airplane
        float littleairPosX = w/4 - littleairplane.getWidth();
        float littleairPosY = h/5 - littleairplane.getHeight();
        c.drawBitmap(littleairplane, littleairPosX, littleairPosY, null);
        //set big submarine
        float bigsubPosX = w/2 - bigsubmarine.getWidth()/10;
        float bigsubPosY = (float) (h/1.5 - bigsubmarine.getHeight()/2);
        c.drawBitmap(bigsubmarine, bigsubPosX, bigsubPosY, null);
        //set medium submarine
        float mediumsubPosX = (float) (w/1.5 - mediumsubmarine.getWidth()/15);
        float mediumsubPosY = (float) (h/1.2 - mediumsubmarine.getHeight());
        c.drawBitmap(mediumsubmarine, mediumsubPosX, mediumsubPosY, null);
        //set little submarine
        float littlesubPosX = w/3 - littlesubmarine.getWidth();
        float littlesubPosY = (float) (h/1.3 - littlesubmarine.getHeight());
        c.drawBitmap(littlesubmarine, littlesubPosX, littlesubPosY, null);
        //set water
        float waterPosX = w/6;
        float waterPosY = h/2 - water.getHeight();
        c.drawBitmap(water, 0, waterPosY, null);
        c.drawBitmap(water, waterPosX, waterPosY, null);
        c.drawBitmap(water, waterPosX * 2, waterPosY,null);
        c.drawBitmap(water, waterPosX * 3, waterPosY, null);
        c.drawBitmap(water, waterPosX * 4, waterPosY, null);
        c.drawBitmap(water, waterPosX * 5, waterPosY, null);
        c.drawBitmap(water, waterPosX * 6, waterPosY, null);
        //set ship position
        float shipPosX = w/2 - battleship.getWidth()/2;
        float shipPosY = h/2 - battleship.getHeight();
        c.drawBitmap(battleship, shipPosX, shipPosY, null);

    }
}
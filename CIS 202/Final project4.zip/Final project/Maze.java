import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;


@SuppressWarnings("serial")
public class Maze extends JPanel implements KeyListener {
	//create 16 rooms
	Room r1;
	Room r2;
	Room r3;
	Room r4;
	Room r5;
	Room r6;
	Room r7;
	Room r8;
	Room r9;
	Room r10;
	Room r11;
	Room r12;
	Room r13;
	Room r14;
	Room r15;
	Room r16;
	
	
	//declare Nephi, Sword, Laban, and Plate
	private Nephi hero;
	private Sword weapon;
	private Plate goldenplate;
	private Laban villain;
	private ArrayList<Drawable> altair;
	
	//instantiate 16 rooms
	public Maze() {
		r1 = new Room(10,10);
		r2 = new Room(70,10);
		r3 = new Room(130,10);
		r4 = new Room(190,10);
		r5 = new Room(10, 70);
		r6 = new Room(70, 70);
		r7 = new Room(130, 70);
		r8 = new Room(190, 70);
		r9 = new Room(10, 130);
		r10 = new Room(70, 130);
		r11 = new Room(130,130);
		r12 = new Room(190,130);
		r13 = new Room(10, 190);
		r14 = new Room(70, 190);
		r15 = new Room(130, 190);
		r16 = new Room(190, 190);
		
		//instantiate Nephi, Sword, Laban, and Plate
		hero = new Nephi();
		weapon = new Sword();
		goldenplate = new Plate();
		villain = new Laban();
		
		
		//set position of Nephi, Sword, Laban, and Plate
		hero.setCurrentRoom(r1);
		weapon.setCurrentRoom(r9);
		goldenplate.setCurrentRoom(r4);
		villain.setCurrentRoom(r15);
		
		//call KeyListener
		addKeyListener(this);
		
		//Array list for drawable interface
		altair = new ArrayList<Drawable>();
		altair.add(r1);
		altair.add(r2);
		altair.add(r3);
		altair.add(r4);
		altair.add(r5);
		altair.add(r6);
		altair.add(r7);
		altair.add(r8);
		altair.add(r9);
		altair.add(r10);
		altair.add(r11);
		altair.add(r12);
		altair.add(r13);
		altair.add(r14);
		altair.add(r15);
		altair.add(r16);
		
	}
	
	@Override
	public void paintComponent(Graphics g) {
		requestFocusInWindow(); //request for recognizing the keyboard
		int w = getWidth();
		int h = getHeight();
		
		//Background Color
		g.setColor(Color.GRAY);
		g.fillRect(0,0,w,h);
		
		//make rooms in paintComponent
		r1.setRoom(r2,null,null,r5);
		r2.setRoom(r3,null,null,null);
		r3.setRoom(r4,null,null,r7);
		r4.setRoom(null,null,null,r8);
		r5.setRoom(r6,null,null,null);
		r6.setRoom(null,null,null,r10);
		r7.setRoom(null,null,null,r11);
		r8.setRoom(null,null,null,null);
		r9.setRoom(r10,null,null,null);
		r10.setRoom(null,null,null,r14);
		r11.setRoom(r12,null,null,null);
		r12.setRoom(null,null,null,null);
		r13.setRoom(r14,null,null,null);
		r14.setRoom(r15,null,null,null);
		r15.setRoom(r16,null,null,null);
		r16.setRoom(null,null,null,null);
		
		//set rooms and exits
		for (Drawable dw : altair) {
			dw.draw(g);
		}
		
		//make Nephi, Sword, plates, and Laban
		hero.draw(g);
		weapon.draw(g);
		goldenplate.draw(g);
		villain.draw(g);
		
		
	}

	public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(300,300);
		window.setContentPane(new Maze());
		window.setVisible(true);
	}

	
	//add three new KeyListenener interface
	public void keyTyped(KeyEvent e) {
		//Do not need to make this methods	
	}

	public void keyPressed(KeyEvent e) {
		int kc = e.getKeyCode();
		int kr = e.getKeyCode();
		
		//move the Nephi
		switch (kc) {
		case KeyEvent.VK_UP:
		case KeyEvent.VK_NUMPAD8:
		case KeyEvent.VK_8:
			hero.moveNorth();
			break;
		case KeyEvent.VK_DOWN:
		case KeyEvent.VK_NUMPAD2:
			hero.moveSouth();
			break;
		case KeyEvent.VK_LEFT:
		case KeyEvent.VK_NUMPAD4:
			hero.moveWest();
			break;
		case KeyEvent.VK_RIGHT:
		case KeyEvent.VK_NUMPAD6:
			hero.moveEast();
			break;
		}	
		repaint();
		//move the Laban
		switch (kr) {
		case KeyEvent.VK_W:
			villain.moveNorth();
			break;
		case KeyEvent.VK_S:
			villain.moveSouth();
			break;
		case KeyEvent.VK_A:
			villain.moveWest();
			break;
		case KeyEvent.VK_D:
			villain.moveEast();
			break;
		}
		
		if (hero.getCurrentRoom() == weapon.getCurrentRoom()) {
			hero.pickUpSword();
			weapon.setCurrentRoom(null);
		}
		
		if (hero.getCurrentRoom() == goldenplate.getCurrentRoom()) {
			JOptionPane.showMessageDialog(null, "Congratulation!!!! You got the Golden Plate!!");
			resetGame();
		}
		
		if (hero.getCurrentRoom() == villain.getCurrentRoom()) {
			if (hero.isArmed() ==true) {
				villain.setCurrentRoom(null);
			} else {
				//pop up the message dialog try again
				JOptionPane.showMessageDialog(null, "Oh man! Game Over! Try again!");
				resetGame();
			}
		}
		
		repaint();
	}

	public void keyReleased(KeyEvent e) {
		//System.out.println("You just let go of a key!");
	}
	
	//reset the game method
	private void resetGame() {
		hero.setCurrentRoom(r1);
		weapon.setCurrentRoom(r9);
		goldenplate.setCurrentRoom(r4);
		villain.setCurrentRoom(r15);
		hero.reset();
	}
}

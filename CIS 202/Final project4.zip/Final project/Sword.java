import javax.swing.ImageIcon;

public class Sword extends Sprite {
	
		public Sword() {
		super();
		image = new ImageIcon("sword.png");
		}
		
		
}
	
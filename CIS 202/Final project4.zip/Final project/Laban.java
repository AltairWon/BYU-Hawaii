import javax.swing.ImageIcon;

public class Laban extends Sprite {
	
		public Laban() {
		super();
		image = new ImageIcon("laban.png");
		}
		
		
}
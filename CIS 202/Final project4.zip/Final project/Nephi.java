import javax.swing.ImageIcon;

public class Nephi extends Sprite {
	
	private boolean hasSword;
	private ImageIcon normalIcon;
	private ImageIcon armedIcon;
	
	public Nephi() {
		super();
		image = new ImageIcon("nephi.png");
		normalIcon = image;
		armedIcon = new ImageIcon("nephisword.png");
		hasSword = false;
		
		
	}
	//pick the sword method
	public void pickUpSword() {
		hasSword = true;
		image = armedIcon;
	}
	// additional moethod for project 4
	public boolean isArmed() {
		return hasSword;
	}
	//set everything back to normal
	public void reset() {
		image = normalIcon;
		hasSword = false;
	}
}
	
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.ImageIcon;

public class Sprite implements Drawable {
	protected Room currentRoom;
	protected ImageIcon image;
	
	public Sprite() {
		this.currentRoom = null;
		this.image = null;
	}
	
	public void setCurrentRoom(Room r) {
		currentRoom = r;
	}
	
	public Room getCurrentRoom() {
		return currentRoom;
	}
	
	public void draw(Graphics g) {
		if (currentRoom != null) {
			Point pics = currentRoom.getPosition();
			image.paintIcon(null, g, pics.x+10, pics.y+10);
		}
	}
	
	//add new methods for final project 3
	public void moveSouth() {
		if (currentRoom.hasSouthExit() == true) {
			currentRoom = currentRoom.getSouthExit();
		}
	}
	public void moveNorth() {
		if (currentRoom.hasNorthExit() == true) {
			currentRoom = currentRoom.getNorthExit();
		}
	}
	public void moveEast() {
		if (currentRoom.hasEastExit() == true) {
			currentRoom = currentRoom.getEastExit();
		}
	}
	public void moveWest() {
		if (currentRoom.hasWestExit() == true) {
			currentRoom = currentRoom.getWestExit();
		}
	}
}

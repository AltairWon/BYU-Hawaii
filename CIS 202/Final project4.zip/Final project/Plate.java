import javax.swing.ImageIcon;

public class Plate extends Sprite {
	
		public Plate() {
		super();
		image = new ImageIcon("plates.png");
		}
		
		
}
	
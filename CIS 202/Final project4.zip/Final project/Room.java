import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

public class Room implements Drawable {
	private Point pos; //position of the x,y point
	private Room exitEast; //exitEast for rooms
	private Room exitWest; //exitWest for rooms
	private Room exitNorth; //exitNorth for rooms
	private Room exitSouth; //exitSouth for rooms
	
	public Point getPosition() {
		return pos;
	}
	
	//set exit condition
	public void setexitEast(Room r){
		this.exitEast = r;
		r.exitWest = this;
	}
	public void setexitWest(Room r){
		this.exitWest = r;
		r.exitEast = this;
	}
	public void setexitNorth(Room r){
		this.exitNorth = r;
		r.exitSouth = this;
	}
	public void setexitSouth(Room r){
		this.exitSouth = r;
		r.exitNorth = this;
	}
	//Room constructor
	public Room(int x, int y){
		this.pos = new Point(x,y);
		this.exitEast = null;
		this.exitWest = null;
		this.exitNorth = null;
		this.exitSouth = null;
	}
	
	// new methods for final project 3
	public boolean hasNorthExit() {
		if(exitNorth == null) {
			return false; 
		} else {
			return true;
		}
	}
		
	public boolean hasSouthExit() {
		if(exitSouth == null) {
			return false; 
		} else {
			return true;
		}
	}
		
	public boolean hasEastExit() {
		if(exitEast == null) {
			return false; 
		} else {
			return true;
		}
	}
		
	public boolean hasWestExit() {
		if(exitWest == null) {
			return false; 
		} else {
			return true;
		}
	}
		
	public Room getNorthExit() {
		return exitNorth;
	}
	public Room getSouthExit() {
		return exitSouth;
	}
	public Room getEastExit() {
		return exitEast;
	}
	public Room getWestExit() {
		return exitWest;
	}
	
	//Add class for final project 4
	public static final int SIZE = 50;
		
	//make new setting room methods
	public void setRoom(Room e, Room w, Room n, Room s) {
		if(e != null){
			setexitEast(e);
		}
		if(w != null){
			setexitWest(w);
		}
		if(s != null){
			setexitSouth(s);
		}
		if(n != null){
			setexitNorth(n);
		}
	}
		//draw method
	@Override
	public void draw(Graphics g){
		g.setColor(Color.BLACK);
		g.drawOval(pos.x,pos.y,SIZE,SIZE);
		if(exitEast != null){
			g.setColor(Color.GRAY);
			g.drawLine(pos.x+SIZE,pos.y+20,pos.x+SIZE,pos.y+30);
			g.setColor(Color.BLACK);
			g.drawLine(pos.x+SIZE,pos.y+20,pos.x+60,pos.y+20);
			g.drawLine(pos.x+SIZE,pos.y+30,pos.x+60,pos.y+30); //draw the line in east position.

		}
		if(exitWest != null){
			g.setColor(Color.GRAY);
			g.drawLine(pos.x,pos.y+20,pos.x,pos.y+30);
		}	
		if(exitNorth != null){
			g.setColor(Color.GRAY);
			g.drawLine(pos.x+20,pos.y,pos.x+30,pos.y);
		}
		if(exitSouth != null){
			g.setColor(Color.GRAY);
			g.drawLine(pos.x+20, pos.y+SIZE,pos.x+30,pos.y+SIZE);
			g.setColor(Color.BLACK);
			g.drawLine(pos.x+20, pos.y+SIZE,pos.x+20,pos.y+60);
			g.drawLine(pos.x+30, pos.y+SIZE,pos.x+30,pos.y+60); // draw the line in south position.
		}
	}
}
